/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeemanagement;

/**
 *
 * @author acier
 */
public class EmployeeManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

    // Use SwingUtilities.invokeLater() to create and display the GUI on the EDT
    javax.swing.SwingUtilities.invokeLater(() -> {
        // Create an instance of the Login class
        Login loginWindow = new Login();
        
        // Display the Login window
        loginWindow.setVisible(true);
    });
}
    }
    

